class PreferenceConstant {
  static const String token = "token";
  static const String refreshToken = "refreshToken";
  static const String onBoardingFlow = "onBoardingFlow";
  static const String language = "language";
  static const String loginData = "loginData";
  static const String userId = "user_id";
}
