// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'req_forgot_password.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ReqForgotPassword _$ReqForgotPasswordFromJson(Map<String, dynamic> json) =>
    ReqForgotPassword(
      email: json['email'] as String,
    );

Map<String, dynamic> _$ReqForgotPasswordToJson(ReqForgotPassword instance) =>
    <String, dynamic>{
      'email': instance.email,
    };
