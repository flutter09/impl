// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'req_login.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ReqLogin _$ReqLoginFromJson(Map<String, dynamic> json) => ReqLogin(
      email: json['email'] as String,
      password: json['password'] as String,
    );

Map<String, dynamic> _$ReqLoginToJson(ReqLogin instance) => <String, dynamic>{
      'email': instance.email,
      'password': instance.password,
    };
