// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'req_send_otp.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ReqSendOtp _$ReqSendOtpFromJson(Map<String, dynamic> json) => ReqSendOtp(
      email: json['email'] as String,
    );

Map<String, dynamic> _$ReqSendOtpToJson(ReqSendOtp instance) =>
    <String, dynamic>{
      'email': instance.email,
    };
