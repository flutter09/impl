import '../../../../base/base_state.dart';

class ChatListState extends BaseState{}
