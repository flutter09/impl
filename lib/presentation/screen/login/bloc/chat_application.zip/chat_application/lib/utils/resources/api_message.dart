const Map<int , String> ApiMessage = {
  0 : "Error Invalid",
  20008 : "Invalid Data"
};