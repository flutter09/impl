class AppStrings {
  static const String noRouteFound = "No Route Found";
  static const String baseUrl = '';
  static const String appTitle = 'LillyWorks';
}